module.exports = {
  "token": "",
  "namaOwner": "© Xdayy $100™",
  "owner": [
    "8239249552"
  ],
  "username": "daiyat19", // USERNAME TELEGRAM
  "namaBot": "daiyatcpanel",
  "versisc": "3.0",
  "thumbnail": "https://qu.ax/sB289",
  
  "forceSubscribeChannels": [
    "@channel1",
    "@channel2"
  ],

  
  //SETTINGS BUY OTOMATIS
  "ApikeyAtlantic": "",
  "GroupReseller": "",
  "GroupAdp": "",
  
  //SETTINGS HARGA PANEL - DIUBAH SESUAI FORMAT BARU
  "hargaPanel": {
    '1gb': 1000,
    '2gb': 1500,
    '3gb': 2000,
    '4gb': 2500,
    '5gb': 3000,
    '6gb': 3500,
    '7gb': 4000,
    '8gb': 4500,
    '9gb': 5000,
    '10gb': 5500,
    'unli': 6000,
    'reseller': 7000,
    'admin': 8000,
    'pt': 9000,
    'owner': 10000,
    'tk': 11000,
    'ceo': 12000
  },
  
  //SETTING PAYMENT, KOSONGKAN SAJA BILA TIDAK ADA
  "dana": "083172911896",
  "gopay": "083172911896",
  "ovo": "",
  "shoppepay": "",
  "qris": "https://d.uguu.se/fZikXnSz.jpg",

  // SERVER 1 - AKTIF
  "domain": "",
  "plta": "",
  "pltc": "",

  // SERVER 2 - TIDAK AKTIF
  "domain2": "",
  "plta2": "",
  "pltc2": "",

  // SERVER 3 - TIDAK AKTIF
  "domain3": "",
  "plta3": "",
  "pltc3": "",

    "loc": "1",
  "eggs": "15",
  
  //SUBDO
  "domains": [
    {
      "name": "panelku-ptero.my.id",
      "zone": "ea719beeec3cfe39b58f0195f848498f",
      "token": "Gb8j0xFasrWB1k80b4BFrIL_f2IgAQ5n66CamFbP"
    },
    {
      "name": "sainsproject.biz.id",
      "zone": "8211830a7911e9028f38018243ea360d",
      "token": "XLllrPcIOIC-S4yQP2iaJ9GELQVrL5agcAtEyGXN"
    },
    {
      "name": "barmodsdomain.my.id",
      "zone": "05478e906fa1556f81ae0eaf86816060",
      "token": "nkIplLsfGW-FSUYEpbSt3_I2-a9JIWZIvGO5W6xN"
    },
    {
      "name": "publicserver.my.id",
      "zone": "b1b16801d28009e899a843b0c8faee34",
      "token": "y_0WKCNCnOgx0sgbcQr-puVTXyTQPN9KErR9vlzN"
    },
    {
      "name": "rikionline.shop",
      "zone": "082ec80d7367d6d4f7c52600034ac635",
      "token": "r3XUyNYtxNQYwZtGUIAChRqe0uTzwV4eVO7JpJ_l"
    },
    {
      "name": "storeid.my.id",
      "zone": "c651c828a01962eb3c530513c7ad7dcf",
      "token": "N-D6fN6la7jY0AnvbWn9FcU6ZHuDitmFXd-JF04g"
    }
  ]
};